package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static Connection connection;

    private DBConnection() {
        // Private constructor to prevent instantiation
    }

    public static Connection getConnection() {
        if (connection == null) {
            initializeConnection();
        }
        return connection;
    }

    private static void initializeConnection() {
        try {
            // Load the JDBC driver (replace "your.jdbc.driver" with your actual JDBC driver)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Get connection properties from property file
            String connectionString = PropertyUtil.getPropertyString();

            // Establish the connection
            connection = DriverManager.getConnection(connectionString);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately
        }
    }
}