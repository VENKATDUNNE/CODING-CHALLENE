package mainmod;

import java.sql.Connection;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import dao.IHospitalServiceImpl;
import entity.Appointment;
import myexceptions.PatientNumberNotFoundException;
import util.DBConnection;




public class MainModule {
    public static void main(String[] args) {
    	Connection connection = DBConnection.getConnection();
        IHospitalServiceImpl service = new IHospitalServiceImpl(connection);
        Scanner scanner = new Scanner(System.in);
        try {
        	
            // Get appointment by ID
            System.out.print("Enter appointment ID to search: ");
            int appointmentId = Integer.parseInt(scanner.nextLine());
            Appointment appointmentById = service.getAppointmentById(appointmentId);
            System.out.println("Appointment by ID: " + appointmentById);

            // Get appointments for a patient
            System.out.print("Enter patient ID to search appointments: ");
            int patientId = Integer.parseInt(scanner.nextLine());
            List<Appointment> appointmentsForPatient = service.getAppointmentsForPatient(patientId);
            System.out.println("Appointments for Patient: " + appointmentsForPatient);

            // Get appointments for a doctor
            System.out.print("Enter doctor ID to search appointments: ");
            int doctorId = Integer.parseInt(scanner.nextLine());
            List<Appointment> appointmentsForDoctor = service.getAppointmentsForDoctor(doctorId);
            System.out.println("Appointments for Doctor: " + appointmentsForDoctor);

            // Schedule an appointment
            Appointment newAppointment = new Appointment();
            System.out.print("Enter patient ID for new appointment: ");
            newAppointment.setPatientId(Integer.parseInt(scanner.nextLine()));
            System.out.print("Enter doctor ID for new appointment: ");
            newAppointment.setDoctorId(Integer.parseInt(scanner.nextLine()));
            System.out.print("Enter appointment date (yyyy-MM-dd): ");
            String appointmentDateString = scanner.nextLine();
            Date appointmentDate = parseDate(appointmentDateString);
            newAppointment.setAppointmentDate(appointmentDate);
            System.out.print("Enter description for the appointment: ");
            newAppointment.setDescription(scanner.nextLine());
            boolean isScheduled = service.scheduleAppointment(newAppointment);
            System.out.println("Appointment Scheduled: " + isScheduled);

            // Update an appointment
            System.out.print("Enter appointment ID to update: ");
            int updateAppointmentId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter new date for the appointment (yyyy-MM-dd): ");
            String newDateString = scanner.nextLine(); // Use a different variable name
            Date newDate = parseDate(newDateString);
            System.out.print("Enter new description for the appointment: ");
            String newDescription = scanner.nextLine();
            boolean isUpdated = service.updateAppointment(new Appointment(updateAppointmentId, newDate, newDescription));
            System.out.println("Appointment Updated: " + isUpdated);

            // Cancel an appointment
            System.out.print("Enter appointment ID to cancel: ");
            int cancelAppointmentId = Integer.parseInt(scanner.nextLine());
            boolean isCancelled = service.cancelAppointment(cancelAppointmentId);
            System.out.println("Appointment Cancelled: " + isCancelled);
            
            System.out.print("Enter patient ID to search: ");
            int patientIdToSearch = Integer.parseInt(scanner.nextLine());

            // Assume findPatientById throws PatientNumberNotFoundException if the patient is not found
            service.findPatientById(patientIdToSearch);
            System.out.println("Patientid found: "+patientId);


        } catch (PatientNumberNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid number format. Please try again.");
        } catch (Exception e) {
            System.err.println("General error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
    private static Date parseDate(String dateString) {
        
        @SuppressWarnings("unused")
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
        return  Date.valueOf(dateString);
}
}