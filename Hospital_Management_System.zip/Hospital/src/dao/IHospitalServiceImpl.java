package dao;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import entity.Appointment;
import entity.Patient;
import myexceptions.PatientNumberNotFoundException;


public class IHospitalServiceImpl implements IHospitalService {
	
	  private Connection connection;


	    
  	public IHospitalServiceImpl(Connection connection) {
          this.connection = connection;
      }  

  	@Override
    public Appointment getAppointmentById(int appointmentId) {

        String query = "SELECT * FROM appointment WHERE appointmentId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, appointmentId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
    	                return new Appointment(
    	                    resultSet.getInt("appointmentId"),
    	                    resultSet.getInt("patientId"),
    	                    resultSet.getInt("doctorId"),
    	                    resultSet.getDate("appointmentDate"),
    	                    resultSet.getString("description")
    	                );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
        return null;
    }

    @Override
    public List<Appointment> getAppointmentsForPatient(int patientId) {
        String query = "SELECT * FROM appointment WHERE patientId = ?";
        List<Appointment> appointments = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, patientId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                	appointments.add(new Appointment(
                            resultSet.getInt("appointmentId"),
                            resultSet.getInt("patientId"),
                            resultSet.getInt("doctorId"),
                            resultSet.getDate("appointmentDate"),
                            resultSet.getString("description")
                        ));
                    
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
        return appointments;
    }

    @Override
    public List<Appointment> getAppointmentsForDoctor(int doctorId) {
        String query = "SELECT * FROM appointment WHERE doctorId = ?";
        List<Appointment> appointments = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, doctorId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                	appointments.add(new Appointment(
                            resultSet.getInt("appointmentId"),
                            resultSet.getInt("patientId"),
                            resultSet.getInt("doctorId"),
                            resultSet.getDate("appointmentDate"),
                            resultSet.getString("description")
                        ));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
        return appointments;
    }

    @Override
    public boolean scheduleAppointment(Appointment appointment) {
        // Example using JDBC:
        String query = "INSERT INTO appointment (patientId, doctorId, appointmentDate, description) VALUES (?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, appointment.getPatientId());
            preparedStatement.setInt(2, appointment.getDoctorId());
            
           try {
        	   if (appointment.getAppointmentDate() != null) {
                preparedStatement.setDate(3, new java.sql.Date(appointment.getAppointmentDate().getTime()));
            } else {
                throw new IllegalArgumentException("Appointment date cannot be null");
            }
        }
        catch (SQLException e) {
        	System.out.println("Appointmentdate is null");
            e.printStackTrace();
        }
            preparedStatement.setString(4, appointment.getDescription());
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace(); 
            return false;
        }
    }

    @Override
    public boolean updateAppointment(Appointment appointment) {
        String query = "UPDATE appointment SET  appointmentDate = ?, description = ? WHERE appointmentId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setDate(1, new java.sql.Date(appointment.getAppointmentDate().getTime()));
            preparedStatement.setString(2, appointment.getDescription());
            preparedStatement.setInt(3, appointment.getAppointmentId());
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace(); 
            return false;
        }
    }

    @Override
    public boolean cancelAppointment(int appointmentId) {
        String query = "DELETE FROM appointment WHERE appointmentId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, appointmentId);
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace(); 
            return false;
        }
    }
    @Override
    public Patient findPatientById(int patientId) throws PatientNumberNotFoundException {
        String query = "SELECT * FROM patient WHERE patientId = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, patientId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Patient patient = new Patient();
                    // Set patient attributes based on the result set
                    return patient;
                } else {
                    throw new PatientNumberNotFoundException("Patient not found with ID: " + patientId);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error while querying the database", e);
        }
    }
}

