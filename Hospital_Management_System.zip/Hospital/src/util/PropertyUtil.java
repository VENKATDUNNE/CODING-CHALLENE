package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyUtil {

    private static final String PROPERTY_FILE = "db.properties";

    private PropertyUtil() {
        // Private constructor to prevent instantiation
    }

    public static String getPropertyString() {
        Properties properties = new Properties();
        try (InputStream input = PropertyUtil.class.getClassLoader().getResourceAsStream(PROPERTY_FILE)) {
            if (input == null) {
                throw new RuntimeException("Sorry, unable to find " + PROPERTY_FILE);
            }
            properties.load(input);
        } catch (IOException ex) {
            ex.printStackTrace(); // Handle the exception appropriately
        }

        // Construct the connection string
        String host = properties.getProperty("db.host");
        String dbName = properties.getProperty("db.name");
        String username = properties.getProperty("db.username");
        String password = properties.getProperty("db.password");
        String port = properties.getProperty("db.port");

        return "jdbc:mysql://" + host + ":" + port + "/" + dbName + "?user=" + username + "&password=" + password;
    }
}